package hangmanGame;

public class HangmanMain {

	public static void main(String[] args) {

		/*
		 * Top menu
		 * 		- Add the catagories - tv series, movies. should it load a list at
		 * startup and access it or read the file each time?
		 *  	- add reset and new game
		 *  	- custom phrase setter goes into a submenu
		 *  	- should allow saving?
		 *  	- vs mode?
		 *  	- add key listener for guesses
		 *  
		 *  	- new game 	> category 	> tv shows	
		 *  							> movies
		 *  	- save game
		 *  	- load game
		 *  	- quit
		 */

	}

}
