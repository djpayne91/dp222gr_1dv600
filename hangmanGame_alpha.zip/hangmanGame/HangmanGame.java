package hangmanGame;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class HangmanGame {

	private Scene gameScene;
	private Scene setPhraseScene;
	private Phrase gamePhrase = new Phrase("");
	private Button[] alphabet = new Button[26];
	private GridPane alphaPane = alphaGrid();
	private BorderPane bPane = new BorderPane();
	private Canvas canvas = new Canvas(600, 300);
	private GraphicsContext gc = canvas.getGraphicsContext2D();

	public HangmanGame() {
		this.gamePhrase = new Phrase("test phrase");
	}

	public Scene newGame() {
		
		MenuBar menu = new MenuBar();
		Menu fileMenu = new Menu("File");
		
		Menu newGameMenu = new Menu("New Game");
		MenuItem catLab = new MenuItem("Categories: ");
		SeparatorMenuItem sep = new SeparatorMenuItem();
		newGameMenu.getItems().add(catLab);
		newGameMenu.getItems().add(sep);
		
		
		
		
		fileMenu.getItems().add(newGameMenu);
		
		menu.getMenus().add(fileMenu);
		
		
		VBox topBox = new VBox(menu);
		Button newPhrase = new Button("New Phrase");
		newPhrase.setOnAction(e -> setPhrase());
		Button reset = new Button("Reset");
		reset.setOnAction(e -> {
			gamePhrase.reset();
			gamePhrase.render(gc);
			for (Button button : alphabet) {
				button.setDisable(false);
			}
		});

		topBox.getChildren().addAll(newPhrase,reset);
		
		bPane.setTop(topBox);

		bPane.setCenter(canvas);
		gamePhrase.render(gc);
		bPane.setBottom(alphaPane);
		gameScene = new Scene(bPane);
		return this.gameScene;
	}

	public void setPhrase() {
		Stage phraseWindow = new Stage();
		GridPane pane = new GridPane();
		pane.setPadding(new Insets(10, 10, 10, 10));
		pane.setVgap(10);
		pane.setHgap(10);
		Label phraseLabel = new Label("Enter phrase:");
		GridPane.setConstraints(phraseLabel, 0, 0);
		TextField phraseField = new TextField(gamePhrase.toString());
		GridPane.setConstraints(phraseField, 1, 0);

		Button setPhrase = new Button("Set Phrase");
		setPhrase.setOnAction(e -> {
			gamePhrase = new Phrase(phraseField.getText());
			phraseWindow.close();
		});
		GridPane.setConstraints(setPhrase, 1, 1);

		pane.getChildren().addAll(phraseLabel, phraseField, setPhrase);

		setPhraseScene = new Scene(pane);
		phraseWindow.setScene(setPhraseScene);
		phraseWindow.show();
	}

	private void checkWin() {
		if (gamePhrase.win()) {
			gc.setFill(Color.WHITE);
			gc.fillText("You Win", 300, 100);
			gc.setFill(Color.BLACK);
			System.out.println("win");
		} else if (!gamePhrase.win() && gamePhrase.getGuesses() >= 6) {
			gc.setFill(Color.DARKRED);
			gc.fillRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
			gc.setFill(Color.BLACK);
			gc.fillText("You lose!", 300, 100);
		}
	}

	// pane for the alphabet
	public GridPane alphaGrid() {
		GridPane grid = new GridPane();

		Button a = new Button("A");
		GridPane.setConstraints(a, 0, 0);
		Button b = new Button("B");
		GridPane.setConstraints(b, 1, 0);
		Button c = new Button("C");
		GridPane.setConstraints(c, 2, 0);
		Button d = new Button("D");
		GridPane.setConstraints(d, 3, 0);
		Button e = new Button("E");
		GridPane.setConstraints(e, 4, 0);
		Button f = new Button("F");
		GridPane.setConstraints(f, 5, 0);
		Button g = new Button("G");
		GridPane.setConstraints(g, 6, 0);
		Button h = new Button("H");
		GridPane.setConstraints(h, 7, 0);
		Button i = new Button("I");
		GridPane.setConstraints(i, 8, 0);
		Button j = new Button("J");
		GridPane.setConstraints(j, 9, 0);
		Button k = new Button("K");
		GridPane.setConstraints(k, 10, 0);
		Button l = new Button("L");
		GridPane.setConstraints(l, 11, 0);
		Button m = new Button("M");
		GridPane.setConstraints(m, 12, 0);
		Button n = new Button("N");
		GridPane.setConstraints(n, 0, 1);
		Button o = new Button("O");
		GridPane.setConstraints(o, 1, 1);
		Button p = new Button("P");
		GridPane.setConstraints(p, 2, 1);
		Button q = new Button("Q");
		GridPane.setConstraints(q, 3, 1);
		Button r = new Button("R");
		GridPane.setConstraints(r, 4, 1);
		Button s = new Button("S");
		GridPane.setConstraints(s, 5, 1);
		Button t = new Button("T");
		GridPane.setConstraints(t, 6, 1);
		Button u = new Button("U");
		GridPane.setConstraints(u, 7, 1);
		Button v = new Button("V");
		GridPane.setConstraints(v, 8, 1);
		Button w = new Button("W");
		GridPane.setConstraints(w, 9, 1);
		Button x = new Button("X");
		GridPane.setConstraints(x, 10, 1);
		Button y = new Button("Y");
		GridPane.setConstraints(y, 11, 1);
		Button z = new Button("Z");
		GridPane.setConstraints(z, 12, 1);

		Button[] alphabetTemp = { a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z };

		// sets behavior and properties of alphabet grid
		int alphacount = 0;
		for (Button button : alphabetTemp) {
			this.alphabet[alphacount] = button;
			char ch = button.getText().charAt(0);
			button.setMinSize(50, 40);
			button.setOnAction(event -> {
				gamePhrase.guess(ch);
				button.setDisable(true);
				gamePhrase.render(gc);
				checkWin();
			});
			alphacount++;
		}

		grid.getChildren().addAll(alphabet);

		return grid;
	}

}
