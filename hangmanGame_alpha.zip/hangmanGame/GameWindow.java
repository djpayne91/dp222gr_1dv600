package hangmanGame;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class GameWindow extends Application {
	
	private Scene gameScreen;
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage window) throws Exception {
		
		window.setTitle("Hangman");
		
		HangmanGame game = new HangmanGame();
		gameScreen = game.newGame();
		
		window.setScene(gameScreen);
		window.show();
		
	}
}
