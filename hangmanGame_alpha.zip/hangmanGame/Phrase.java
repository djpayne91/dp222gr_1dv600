package hangmanGame;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

public class Phrase {

	private Letter[] phrase;
	private int guesses;

	public Phrase(String str) {
		this.phrase = new Letter[str.length()];
		for (int i = 0; i < str.length(); i++) {
			this.phrase[i] = new Letter(str.charAt(i));
		}
	}
	
	public int getGuesses() {
		return guesses;
	}

	public String print() {
		String out = "";
		for (Letter letter : phrase) {
			if (letter.isShown()) {
				out += letter.getLetter();
				System.out.print(letter.getLetter());
			} else {
				out += '_';
				System.out.print('_');
			}
		}
		System.out.println("   guesses: " + guesses);
		return out;
	}
	
	public boolean win() {
		for (Letter letter : phrase) {
			if (!letter.isShown())
				return false;
		}
		return true;
	}

	public void guess(char c) {
		boolean wrong = true;
		for (Letter letter : phrase) {
			if (Character.toLowerCase(letter.getLetter()) == Character.toLowerCase(c)) {
				letter.setShown(true);
				wrong = false;
			}
		}
		if (wrong)
			guesses++;
	}

	public String toString() {
		String out = "";
		for (Letter letter : phrase) {
			out += letter.getLetter();
		}
		return out;
	}

	public void reset() {
		for (Letter l : phrase) {
			if (Character.isLetter(l.getLetter()))
				l.setShown(false);
		}
		guesses = 0;
	}
	
	public void render(GraphicsContext gc) {
		String str = "";
		gc.setFill(Color.BLACK);
		gc.setFont(new Font(24));
		for(int i = 0; i < phrase.length; i++) {
			if(phrase[i].isShown())
			str+= phrase[i].getLetter();
			else str+="_\u200A";
			}
		gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
		gc.fillRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
		gc.setFill(Color.WHITE);
		gc.setTextAlign(TextAlignment.CENTER);
		gc.fillText(str, 300, 275);
	}

}
