package hangmanGame;

public class HangmanGame {

	protected Phrase gamePhrase = new Phrase("");
	protected int guessesLeft = 6;

	public HangmanGame(String phrase) {
		this.gamePhrase = new Phrase(phrase);
	}

	public boolean checkWin() {
		return gamePhrase.win() && guessesLeft >= 0;
	}

}
