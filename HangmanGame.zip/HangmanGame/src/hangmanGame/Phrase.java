package hangmanGame;

public class Phrase {

	private Letter[] phrase;
	
	public Phrase(String str) {
		this.phrase = new Letter[str.length()];
		for (int i = 0; i < str.length(); i++) {
			this.phrase[i] = new Letter(str.charAt(i));
		}
	}

//	public String print() {
//		String out = "";
//		for (Letter letter : phrase) {
//			if (letter.isShown()) {
//				out += letter.getLetter();
//				System.out.print(letter.getLetter());
//			} else {
//				out += '_';
//				System.out.print('_');
//			}
//		}
//		System.out.println("   guesses: " + guesses);
//		return out;
//	}
	
	public boolean win() {
		for (Letter letter : phrase) {
			if (!letter.isShown())
				return false;
		}
		return true;
	}

	public boolean guess(char c) {
		boolean out = false;
		for (Letter letter : phrase) {
			if (Character.toLowerCase(letter.getLetter()) == Character.toLowerCase(c)) {
				letter.setShown(true);
				out = true;
			}
		}
		return out;
	}

	public String toString() {
		StringBuilder out = new StringBuilder();
		for (Letter letter : phrase) {
			if(letter.isShown()) {
				out.append(letter.getLetter());
			}
			else
				out.append("_\u200A");
			
		}
		return out.toString();
	}
	
	public String getPhrase() {
		StringBuilder out = new StringBuilder();
		for(Letter l : phrase) {
			out.append(l.getLetter());
		}
		return out.toString();
	}

	public void reset() {
		for (Letter l : phrase) {
			if (Character.isLetter(l.getLetter()))
				l.setShown(false);
		}
	}
	
	/*public void render(GraphicsContext gc) {
		String str = "";
		gc.setFill(Color.BLACK);
		gc.setFont(new Font(24));
		for(int i = 0; i < phrase.length; i++) {
			if(phrase[i].isShown())
			str+= phrase[i].getLetter();
			else str+="_\u200A";
			}
		gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
		gc.fillRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
		gc.setFill(Color.WHITE);
		gc.setTextAlign(TextAlignment.CENTER);
		gc.fillText(str, 300, 275);
	}
*/
}
